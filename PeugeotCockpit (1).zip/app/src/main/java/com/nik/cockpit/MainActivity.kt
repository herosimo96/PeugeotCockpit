package com.nik.cockpit

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NL : NotificationListenerService()

class MainActivity : Activity(), LocationListener {
    private lateinit var cv: CockpitView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cv = CockpitView(this)
        setContentView(cv)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) startGps()
        else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startGps()
    }

    private fun startGps() {
        try {
            (getSystemService(Context.LOCATION_SERVICE) as LocationManager)
                .requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
        } catch (e: SecurityException) {
        }
    }

    override fun onLocationChanged(location: Location) { cv.onGps(location.speed) }
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    @Deprecated("old api")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onBackPressed() {}
}

class CockpitView(private val act: Activity) : View(act) {
    private class Th(val name: String, val style: Int, val color: Int, val sw: Float)

    private val prefs = act.getSharedPreferences("cp", Context.MODE_PRIVATE)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val themes = arrayOf(
        Th("Moderno blu", 0, 0xFF3EA6FF.toInt(), 14f),
        Th("Classico bianco", 1, 0xFFE8EEF5.toInt(), 4f),
        Th("Sport rosso", 0, 0xFFFF5A5A.toInt(), 22f),
        Th("Minimal verde", 0, 0xFF4ADE80.toInt(), 4f),
        Th("Retro ambra", 1, 0xFFFFB020.toInt(), 4f),
        Th("Neon viola", 2, 0xFFB26BFF.toInt(), 18f),
        Th("Ghiaccio", 0, 0xFF7DF9FF.toInt(), 9f),
        Th("Racing giallo", 2, 0xFFFFD400.toInt(), 22f),
        Th("Matrix", 2, 0xFF39FF14.toInt(), 14f),
        Th("Puro", 0, 0xFFE8EEF5.toInt(), 3f)
    )
    private val wNames = arrayOf("OROLOGIO", "MUSICA", "RADIO", "NAVIGAZIONE")
    private val white = 0xFFE8EEF5.toInt()
    private val grey = 0xFF9FB0C3.toInt()
    private val red = 0xFFFF6B6B.toInt()
    private var theme = prefs.getInt("theme", 0)
    private var unit = prefs.getInt("unit", 0)
    private var page = 0
    private var odo = prefs.getFloat("odo", 0f)
    private var speed = 0f
    private var last = 0L
    private var phase = 0f
    private var sc = 1f
    private var vw = 1280f
    private var doors = 0
    private var hhmm = ""
    private var dateStr = ""
    private var ctrl: MediaController? = null
    private var lastPoll = 0L
    private val icons = HashMap<String, Drawable?>()
    private val hits = ArrayList<Pair<RectF, Int>>()

    fun onGps(ms: Float) {
        val now = System.currentTimeMillis()
        if (last > 0) odo += ms * (now - last) / 1000000f
        last = now
        speed = ms * 3.6f
        prefs.edit().putFloat("odo", odo).apply()
    }

    // bit 1 = sportello sinistro, 2 = destro, 4 = baule (per collegare in futuro i dati dell'auto)
    fun setDoors(bits: Int) { doors = bits; postInvalidate() }

    private fun getW(pg: Int): Int =
        if (pg == 0) prefs.getInt("widget", 0) else prefs.getInt("pw$pg", intArrayOf(0, 0, 1, 3)[pg])

    private fun setW(pg: Int, v: Int) {
        prefs.edit().putInt(if (pg == 0) "widget" else "pw$pg", v).apply()
    }

    private val gd = GestureDetector(act, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapUp(e: MotionEvent): Boolean { tap(e.x / sc, e.y / sc, false); return true }
        override fun onLongPress(e: MotionEvent) { tap(e.x / sc, e.y / sc, true) }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 700f) {
                page = if (vx < 0) minOf(page + 1, 3) else maxOf(page - 1, 0)
                invalidate()
                return true
            }
            return false
        }
    })

    override fun onTouchEvent(e: MotionEvent): Boolean = gd.onTouchEvent(e)

    private fun pollMedia() {
        val now = System.currentTimeMillis()
        if (now - lastPoll < 1000) return
        lastPoll = now
        try {
            val msm = act.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val l = msm.getActiveSessions(ComponentName(act, NL::class.java))
            ctrl = l.firstOrNull { s -> s.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
        } catch (e: SecurityException) {
            ctrl = null
        }
    }

    private fun doAction(a: Int) {
        val m = ctrl
        when (a) {
            0 -> m?.transportControls?.skipToPrevious()
            1 -> if (m?.playbackState?.state == PlaybackState.STATE_PLAYING) m?.transportControls?.pause() else m?.transportControls?.play()
            2 -> m?.transportControls?.skipToNext()
            3 -> launchPkg("radioPkg")
            4 -> launchPkg("navPkg")
            else -> {}
        }
    }

    private fun launchPkg(key: String) {
        val pkg = prefs.getString(key, null)
        if (pkg == null) chooseApp(key)
        else act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) }
    }

    private fun tap(x: Float, y: Float, long: Boolean) {
        if (!long && x > vw - 100f && y < 100f) { settings(); return }
        if (!long) {
            for (h in hits) if (h.first.contains(x, y)) { doAction(h.second); invalidate(); return }
        }
        if (page >= 1) {
            if (!long) setW(page, (getW(page) + 1) % 4)
            invalidate()
            return
        }
        for (i in 0..5) {
            val tx = vw / 2 - 338f + i * 116f
            if (x >= tx && x <= tx + 96f && y >= 556f && y <= 652f) {
                val pkg = prefs.getString("t$i", null)
                if (pkg == null || long) chooseApp("t$i")
                else act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) }
                return
            }
        }
        val dx = x - 220f
        val dy = y - 300f
        if (dx * dx + dy * dy < 190f * 190f && long) {
            theme = (theme + 1) % themes.size
            prefs.edit().putInt("theme", theme).apply()
        } else if (x > vw - 410f && y < 500f && !long) {
            setW(0, (getW(0) + 1) % 4)
        }
        invalidate()
    }

    private fun chooseApp(key: String) {
        val pm = act.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(q, 0)
            .filter { r -> r.activityInfo.packageName != act.packageName }
            .sortedBy { r -> r.loadLabel(pm).toString().lowercase() }
        val names = list.map { r -> r.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(act).setTitle("Scegli app").setItems(names) { _, w ->
            prefs.edit().putString(key, list[w].activityInfo.packageName).apply()
            icons.clear()
            invalidate()
        }.show()
    }

    private fun appLabel(key: String): String {
        val pkg = prefs.getString(key, null) ?: return "nessuna"
        return try {
            val pm = act.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            "nessuna"
        }
    }

    private fun settings() {
        val n = wNames.map { s -> s.lowercase() }
        val items = arrayOf(
            "Tema tachimetro: " + themes[theme].name,
            "Widget a destra: " + n[getW(0)],
            "Pagina 2: " + n[getW(1)],
            "Pagina 3: " + n[getW(2)],
            "Pagina 4: " + n[getW(3)],
            "App radio: " + appLabel("radioPkg"),
            "App navigazione: " + appLabel("navPkg"),
            "Unita: " + (if (unit == 0) "km/h" else "mph"),
            "Imposta km totali",
            "Abilita controllo musica",
            "Test sportelli aperti"
        )
        AlertDialog.Builder(act).setTitle("Impostazioni").setItems(items) { _, w ->
            when (w) {
                0 -> pickTheme()
                1 -> pickWidget(0)
                2 -> pickWidget(1)
                3 -> pickWidget(2)
                4 -> pickWidget(3)
                5 -> chooseApp("radioPkg")
                6 -> chooseApp("navPkg")
                7 -> { unit = 1 - unit; prefs.edit().putInt("unit", unit).apply(); invalidate() }
                8 -> askOdo()
                9 -> try {
                    act.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(act, "Vai in Impostazioni Android > Accesso alle notifiche e abilita Peugeot Cockpit", Toast.LENGTH_LONG).show()
                }
                10 -> { doors = (doors + 1) % 5; invalidate() }
                else -> {}
            }
        }.show()
    }

    private fun pickTheme() {
        AlertDialog.Builder(act).setTitle("Tema tachimetro")
            .setItems(themes.map { t -> t.name }.toTypedArray()) { _, w ->
                theme = w
                prefs.edit().putInt("theme", w).apply()
                invalidate()
            }.show()
    }

    private fun pickWidget(pg: Int) {
        AlertDialog.Builder(act).setTitle("Widget")
            .setItems(wNames.map { s -> s.lowercase() }.toTypedArray()) { _, w -> setW(pg, w); invalidate() }.show()
    }

    private fun askOdo() {
        val et = EditText(act)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        AlertDialog.Builder(act).setTitle("Km totali dell'auto").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val v = et.text.toString().toFloatOrNull()
                if (v != null) { odo = v; prefs.edit().putFloat("odo", odo).apply(); invalidate() }
            }.setNegativeButton("Annulla", null).show()
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false) {
        p.style = Paint.Style.FILL
        p.color = color
        p.textSize = size
        p.textAlign = Paint.Align.CENTER
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        c.drawText(s, x, y, p)
    }

    private fun box(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        c.drawRoundRect(RectF(l, t, r, b), rad, rad, p)
    }

    private fun gauge(c: Canvas, cx: Float, cy: Float, spd: Float) {
        val th = themes[theme]
        val frac = minOf(spd / 200f, 1f)
        p.style = Paint.Style.FILL
        p.color = 0xFF0E131B.toInt()
        c.drawCircle(cx, cy, 186f, p)
        val rect = RectF(cx - 164f, cy - 164f, cx + 164f, cy + 164f)
        var numY = cy + 40f
        var numSize = 120f
        var unitY = cy + 78f
        var odoY = cy + 130f
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        if (th.style == 1) {
            p.strokeWidth = 3f
            p.color = 0xFF2C3948.toInt()
            c.drawCircle(cx, cy, 170f, p)
            p.strokeWidth = th.sw
            p.color = th.color
            for (i in 0..10) {
                val a = Math.toRadians(135.0 + 27.0 * i)
                val ca = Math.cos(a).toFloat()
                val sa = Math.sin(a).toFloat()
                c.drawLine(cx + 136f * ca, cy + 136f * sa, cx + 158f * ca, cy + 158f * sa, p)
            }
            val na = Math.toRadians(135.0 + 270.0 * frac)
            p.strokeWidth = 6f
            c.drawLine(cx, cy, cx + 120f * Math.cos(na).toFloat(), cy + 120f * Math.sin(na).toFloat(), p)
            p.style = Paint.Style.FILL
            c.drawCircle(cx, cy, 10f, p)
            numY = cy + 96f; numSize = 56f; unitY = cy + 122f; odoY = cy + 150f
        } else if (th.style == 2) {
            p.strokeWidth = th.sw
            p.strokeCap = Paint.Cap.BUTT
            for (i in 0 until 30) {
                p.color = if (i < frac * 30) th.color else 0xFF1D2733.toInt()
                c.drawArc(rect, 135f + i * 9f, 6.5f, false, p)
            }
        } else {
            p.strokeWidth = th.sw
            p.color = 0xFF1D2733.toInt()
            c.drawArc(rect, 135f, 270f, false, p)
            if (frac > 0.005f) {
                p.color = th.color
                c.drawArc(rect, 135f, 270f * frac, false, p)
            }
        }
        val shown = if (unit == 1) (spd * 0.621f).toInt() else spd.toInt()
        txt(c, shown.toString(), cx, numY, numSize, white)
        txt(c, if (unit == 1) "MPH" else "KM/H", cx, unitY, if (th.style == 1) 16f else 20f, grey)
        txt(c, odo.toInt().toString() + " km", cx, odoY, if (th.style == 1) 18f else 22f, grey)
    }

    private fun button(c: Canvas, cx: Float, cy: Float, w: Float, h: Float, label: String, action: Int, ac: Int, size: Float) {
        box(c, cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, h / 2, ac)
        txt(c, label, cx, cy + size * 0.35f, size, 0xFF0A0D12.toInt(), true)
        hits.add(Pair(RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2), action))
    }

    private fun icon(c: Canvas, kind: Int, x: Float, y: Float, s: Float, playing: Boolean, col: Int) {
        p.style = Paint.Style.FILL
        p.color = col
        val pa = Path()
        if (kind == 0) {
            pa.moveTo(x + s * 0.5f, y - s * 0.5f); pa.lineTo(x - s * 0.4f, y); pa.lineTo(x + s * 0.5f, y + s * 0.5f); pa.close()
            c.drawRect(x - s * 0.7f, y - s * 0.5f, x - s * 0.5f, y + s * 0.5f, p)
        } else if (kind == 2) {
            pa.moveTo(x - s * 0.5f, y - s * 0.5f); pa.lineTo(x + s * 0.4f, y); pa.lineTo(x - s * 0.5f, y + s * 0.5f); pa.close()
            c.drawRect(x + s * 0.5f, y - s * 0.5f, x + s * 0.7f, y + s * 0.5f, p)
        } else if (playing) {
            c.drawRect(x - s * 0.45f, y - s * 0.5f, x - s * 0.12f, y + s * 0.5f, p)
            c.drawRect(x + s * 0.12f, y - s * 0.5f, x + s * 0.45f, y + s * 0.5f, p)
        } else {
            pa.moveTo(x - s * 0.35f, y - s * 0.55f); pa.lineTo(x - s * 0.35f, y + s * 0.55f); pa.lineTo(x + s * 0.55f, y); pa.close()
        }
        c.drawPath(pa, p)
    }

    private fun cut(s: String): String = if (s.length > 16) s.take(15) + "…" else s

    private fun media(c: Canvas, cx: Float, cy: Float, k: Float, ac: Int) {
        pollMedia()
        val m = ctrl
        val title = m?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Nessun brano"
        val artist = m?.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Abilita il controllo musica"
        txt(c, cut(title), cx, cy - 14f * k, 26f * k, white)
        txt(c, cut(artist), cx, cy + 18f * k, 18f * k, grey)
        val playing = m?.playbackState?.state == PlaybackState.STATE_PLAYING
        val by = cy + 80f * k
        val g = 76f * k
        val r = 26f * k
        for (j in 0..2) {
            val bx = cx + (j - 1) * g
            p.style = Paint.Style.FILL
            p.color = if (j == 1) ac else 0xFF1D2733.toInt()
            c.drawCircle(bx, by, r, p)
            icon(c, j, bx, by, 12f * k, playing, if (j == 1) 0xFF0A0D12.toInt() else white)
            hits.add(Pair(RectF(bx - r, by - r, bx + r, by + r), j))
        }
    }

    private fun widgetBody(c: Canvas, type: Int, cx: Float, cy: Float, k: Float, ac: Int) {
        txt(c, wNames[type], cx, cy - 78f * k, 18f * k, ac, true)
        when (type) {
            0 -> {
                txt(c, hhmm, cx, cy + 20f * k, 70f * k, white)
                txt(c, dateStr, cx, cy + 62f * k, 20f * k, grey)
            }
            1 -> media(c, cx, cy, k, ac)
            2 -> {
                txt(c, appLabel("radioPkg"), cx, cy - 6f * k, 26f * k, white)
                button(c, cx, cy + 60f * k, 210f * k, 56f * k, "Apri radio", 3, ac, 22f * k)
            }
            else -> {
                txt(c, appLabel("navPkg"), cx, cy - 6f * k, 26f * k, white)
                button(c, cx, cy + 60f * k, 210f * k, 56f * k, "Apri navigazione", 4, ac, 22f * k)
            }
        }
    }

    private fun car(c: Canvas, cx: Float, spd: Float) {
        c.save()
        c.translate(cx - 200f, 100f)
        if (spd > 3f && doors == 0) {
            phase = (phase + spd * 0.04f) % 26f
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            p.color = 0xFF243142.toInt()
            p.pathEffect = DashPathEffect(floatArrayOf(14f, 12f), phase)
            c.drawLine(195f, 300f, 60f, 420f, p)
            c.drawLine(205f, 300f, 340f, 420f, p)
            c.drawLine(200f, 300f, 200f, 420f, p)
            p.pathEffect = null
        }
        p.style = Paint.Style.FILL
        p.color = 0xFF05070A.toInt()
        c.drawOval(RectF(30f, 302f, 370f, 334f), p)
        val cab = Path()
        cab.moveTo(82f, 150f); cab.lineTo(108f, 62f); cab.quadTo(112f, 48f, 130f, 48f)
        cab.lineTo(270f, 48f); cab.quadTo(288f, 48f, 292f, 62f); cab.lineTo(318f, 150f); cab.close()
        p.color = 0xFF6F7882.toInt()
        c.drawPath(cab, p)
        val win = Path()
        win.moveTo(106f, 142f); win.lineTo(126f, 70f); win.lineTo(274f, 70f); win.lineTo(294f, 142f); win.close()
        p.color = 0xFF141A22.toInt()
        c.drawPath(win, p)
        val door = Path()
        if ((doors and 1) != 0) { door.moveTo(40f, 160f); door.lineTo(4f, 178f); door.lineTo(4f, 276f); door.lineTo(40f, 268f); door.close() }
        if ((doors and 2) != 0) { door.moveTo(360f, 160f); door.lineTo(396f, 178f); door.lineTo(396f, 276f); door.lineTo(360f, 268f); door.close() }
        p.color = 0xFFAAB1B8.toInt()
        c.drawPath(door, p)
        box(c, 40f, 148f, 360f, 278f, 30f, 0xFF8D949C.toInt())
        box(c, 46f, 162f, 110f, 202f, 8f, 0xFFC8202B.toInt())
        box(c, 290f, 162f, 354f, 202f, 8f, 0xFFC8202B.toInt())
        box(c, 162f, 214f, 238f, 240f, 4f, 0xFFE8E8E8.toInt())
        box(c, 56f, 250f, 344f, 290f, 14f, 0xFF3A4047.toInt())
        box(c, 62f, 288f, 114f, 318f, 6f, 0xFF0B0D10.toInt())
        box(c, 286f, 288f, 338f, 318f, 6f, 0xFF0B0D10.toInt())
        if ((doors and 4) != 0) box(c, 100f, 34f, 300f, 46f, 6f, red)
        if (doors == 0) {
            txt(c, if (spd > 3f) "IN MOVIMENTO" else "FERMA", 200f, 358f, 15f, grey)
        } else {
            val parts = ArrayList<String>()
            if ((doors and 1) != 0) parts.add("SPORTELLO SX")
            if ((doors and 2) != 0) parts.add("SPORTELLO DX")
            if ((doors and 4) != 0) parts.add("BAULE")
            txt(c, parts.joinToString(" + ") + " APERTO", 200f, 358f, 15f, red, true)
        }
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        sc = height / 720f
        vw = width / sc
        hits.clear()
        c.drawColor(0xFF0A0D12.toInt())
        c.save()
        c.scale(sc, sc)
        val now = Date()
        hhmm = SimpleDateFormat("HH:mm", Locale.ITALY).format(now)
        dateStr = SimpleDateFormat("EEEE d MMMM", Locale.ITALY).format(now)
        val spd = if (System.currentTimeMillis() - last > 3000) 0f else speed
        val ac = themes[theme].color
        txt(c, hhmm, 90f, 56f, 32f, white, true)
        txt(c, "PEUGEOT 2008", vw / 2, 50f, 18f, grey)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = grey
        c.drawCircle(vw - 50f, 44f, 6f, p)
        p.pathEffect = DashPathEffect(floatArrayOf(5f, 5f), 0f)
        c.drawCircle(vw - 50f, 44f, 15f, p)
        p.pathEffect = null
        if (page == 0) {
            gauge(c, 220f, 300f, spd)
            val wx = vw - 220f
            p.style = Paint.Style.FILL
            p.color = 0xFF0E131B.toInt()
            c.drawCircle(wx, 300f, 186f, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 10f
            p.strokeCap = Paint.Cap.ROUND
            p.color = 0xFF1D2733.toInt()
            c.drawCircle(wx, 300f, 164f, p)
            widgetBody(c, getW(0), wx, 310f, 1f, ac)
            for (k in 0..3) txt(c, wNames[k].lowercase(), wx - 135f + k * 90f, 520f, 14f, if (k == getW(0)) ac else grey)
            car(c, vw / 2, spd)
            for (i in 0..5) {
                val tx = vw / 2 - 338f + i * 116f
                box(c, tx, 556f, tx + 96f, 652f, 22f, 0xFF141B25.toInt())
                val pkg = prefs.getString("t$i", null)
                val ic = if (pkg == null) null else icons.getOrPut(pkg) {
                    try { act.packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }
                }
                if (ic != null) {
                    ic.setBounds((tx + 20f).toInt(), 576, (tx + 76f).toInt(), 632)
                    ic.draw(c)
                } else txt(c, "+", tx + 48f, 614f, 44f, grey)
            }
        } else {
            widgetBody(c, getW(page), vw / 2, 330f, 2.2f, ac)
        }
        var x = vw / 2 - 35f
        for (k in 0..3) {
            val w = if (k == page) 22f else 8f
            box(c, x, 692f, x + w, 700f, 4f, if (k == page) ac else 0xFF3A4655.toInt())
            x += w + 8f
        }
        c.restore()
        postInvalidateDelayed(50)
    }
}

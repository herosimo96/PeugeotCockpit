package com.nik.cockpit

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), LocationListener {
    private lateinit var cv: CockpitView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cv = CockpitView(this)
        setContentView(cv)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) startGps()
        else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startGps()
    }

    private fun startGps() {
        try {
            (getSystemService(Context.LOCATION_SERVICE) as LocationManager)
                .requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
        } catch (e: SecurityException) {
        }
    }

    override fun onLocationChanged(location: Location) { cv.onGps(location.speed) }
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    @Deprecated("old api")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onBackPressed() {}
}

class CockpitView(private val act: Activity) : View(act) {
    private val prefs = act.getSharedPreferences("cp", Context.MODE_PRIVATE)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val accents = intArrayOf(0xFF3EA6FF.toInt(), 0xFFE8EEF5.toInt(), 0xFFFF5A5A.toInt(), 0xFF4ADE80.toInt())
    private val widgetNames = arrayOf("OROLOGIO", "MUSICA", "RADIO")
    private var theme = prefs.getInt("theme", 0)
    private var widget = prefs.getInt("widget", 0)
    private var page = 0
    private var odo = prefs.getFloat("odo", 0f)
    private var speed = 0f
    private var last = 0L
    private var phase = 0f
    private var sc = 1f
    private var vw = 1280f
    private val icons = HashMap<String, Drawable?>()

    fun onGps(ms: Float) {
        val now = System.currentTimeMillis()
        if (last > 0) odo += ms * (now - last) / 1000000f
        last = now
        speed = ms * 3.6f
        prefs.edit().putFloat("odo", odo).apply()
    }

    private val gd = GestureDetector(act, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapUp(e: MotionEvent): Boolean { tap(e.x / sc, e.y / sc, false); return true }
        override fun onLongPress(e: MotionEvent) { tap(e.x / sc, e.y / sc, true) }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 700f) {
                page = if (vx < 0) minOf(page + 1, 1) else maxOf(page - 1, 0)
                invalidate()
                return true
            }
            return false
        }
    })

    override fun onTouchEvent(e: MotionEvent): Boolean = gd.onTouchEvent(e)

    private fun tap(x: Float, y: Float, long: Boolean) {
        if (page == 1) {
            if (!long) { widget = (widget + 1) % 3; prefs.edit().putInt("widget", widget).apply() }
            invalidate()
            return
        }
        for (i in 0..5) {
            val tx = vw / 2 - 338f + i * 116f
            if (x >= tx && x <= tx + 96f && y >= 556f && y <= 652f) {
                val pkg = prefs.getString("t$i", null)
                if (pkg == null || long) choose(i)
                else act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) }
                return
            }
        }
        val dx = x - 220f
        val dy = y - 300f
        if (dx * dx + dy * dy < 190f * 190f && long) {
            theme = (theme + 1) % accents.size
            prefs.edit().putInt("theme", theme).apply()
        } else if (x > vw - 410f && y < 500f && !long) {
            widget = (widget + 1) % 3
            prefs.edit().putInt("widget", widget).apply()
        }
        invalidate()
    }

    private fun choose(i: Int) {
        val pm = act.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(q, 0)
            .filter { r -> r.activityInfo.packageName != act.packageName }
            .sortedBy { r -> r.loadLabel(pm).toString().lowercase() }
        val names = list.map { r -> r.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(act).setTitle("Scegli app").setItems(names) { _, w ->
            prefs.edit().putString("t$i", list[w].activityInfo.packageName).apply()
            icons.clear()
            invalidate()
        }.show()
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false) {
        p.style = Paint.Style.FILL
        p.color = color
        p.textSize = size
        p.textAlign = Paint.Align.CENTER
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        c.drawText(s, x, y, p)
    }

    private fun ring(c: Canvas, cx: Float, cy: Float, r: Float, frac: Float, color: Int, sw: Float) {
        p.style = Paint.Style.FILL
        p.color = 0xFF0E131B.toInt()
        c.drawCircle(cx, cy, r + 22f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.strokeCap = Paint.Cap.ROUND
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        p.color = 0xFF1D2733.toInt()
        c.drawArc(rect, 135f, 270f, false, p)
        if (frac > 0.005f) {
            p.color = color
            c.drawArc(rect, 135f, 270f * frac, false, p)
        }
    }

    private fun box(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        c.drawRoundRect(RectF(l, t, r, b), rad, rad, p)
    }

    private fun car(c: Canvas, cx: Float, spd: Float) {
        c.save()
        c.translate(cx - 200f, 100f)
        if (spd > 3f) {
            phase = (phase + spd * 0.04f) % 26f
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            p.color = 0xFF243142.toInt()
            p.pathEffect = DashPathEffect(floatArrayOf(14f, 12f), phase)
            c.drawLine(195f, 300f, 60f, 420f, p)
            c.drawLine(205f, 300f, 340f, 420f, p)
            c.drawLine(200f, 300f, 200f, 420f, p)
            p.pathEffect = null
        }
        p.style = Paint.Style.FILL
        p.color = 0xFF05070A.toInt()
        c.drawOval(RectF(30f, 302f, 370f, 334f), p)
        val cab = Path()
        cab.moveTo(82f, 150f); cab.lineTo(108f, 62f); cab.quadTo(112f, 48f, 130f, 48f)
        cab.lineTo(270f, 48f); cab.quadTo(288f, 48f, 292f, 62f); cab.lineTo(318f, 150f); cab.close()
        p.color = 0xFF6F7882.toInt()
        c.drawPath(cab, p)
        val win = Path()
        win.moveTo(106f, 142f); win.lineTo(126f, 70f); win.lineTo(274f, 70f); win.lineTo(294f, 142f); win.close()
        p.color = 0xFF141A22.toInt()
        c.drawPath(win, p)
        box(c, 40f, 148f, 360f, 278f, 30f, 0xFF8D949C.toInt())
        box(c, 46f, 162f, 110f, 202f, 8f, 0xFFC8202B.toInt())
        box(c, 290f, 162f, 354f, 202f, 8f, 0xFFC8202B.toInt())
        box(c, 162f, 214f, 238f, 240f, 4f, 0xFFE8E8E8.toInt())
        box(c, 56f, 250f, 344f, 290f, 14f, 0xFF3A4047.toInt())
        box(c, 62f, 288f, 114f, 318f, 6f, 0xFF0B0D10.toInt())
        box(c, 286f, 288f, 338f, 318f, 6f, 0xFF0B0D10.toInt())
        txt(c, if (spd > 3f) "IN MOVIMENTO" else "FERMA", 200f, 358f, 15f, 0xFF9FB0C3.toInt())
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        sc = height / 720f
        vw = width / sc
        c.drawColor(0xFF0A0D12.toInt())
        c.save()
        c.scale(sc, sc)
        val now = Date()
        val hhmm = SimpleDateFormat("HH:mm", Locale.ITALY).format(now)
        val date = SimpleDateFormat("EEEE d MMMM", Locale.ITALY).format(now)
        val spd = if (System.currentTimeMillis() - last > 3000) 0f else speed
        val ac = accents[theme]
        val grey = 0xFF9FB0C3.toInt()
        val white = 0xFFE8EEF5.toInt()
        txt(c, hhmm, 90f, 56f, 32f, white, true)
        txt(c, "PEUGEOT 2008", vw / 2, 50f, 18f, grey)
        if (page == 0) {
            ring(c, 220f, 300f, 164f, minOf(spd / 200f, 1f), ac, 14f)
            txt(c, spd.toInt().toString(), 220f, 340f, 120f, white)
            txt(c, "KM/H", 220f, 378f, 20f, grey)
            txt(c, odo.toInt().toString() + " km", 220f, 430f, 22f, grey)
            val wx = vw - 220f
            ring(c, wx, 300f, 164f, 0.35f, ac, 10f)
            txt(c, widgetNames[widget], wx, 240f, 18f, ac, true)
            if (widget == 0) {
                txt(c, hhmm, wx, 320f, 70f, white)
                txt(c, date, wx, 362f, 20f, grey)
            } else {
                txt(c, "In arrivo", wx, 320f, 34f, white)
                txt(c, "prossima versione", wx, 358f, 18f, grey)
            }
            for (k in 0..2) txt(c, widgetNames[k].lowercase(), wx - 90f + k * 90f, 520f, 15f, if (k == widget) ac else grey)
            car(c, vw / 2, spd)
            for (i in 0..5) {
                val tx = vw / 2 - 338f + i * 116f
                box(c, tx, 556f, tx + 96f, 652f, 22f, 0xFF141B25.toInt())
                val pkg = prefs.getString("t$i", null)
                val ic = if (pkg == null) null else icons.getOrPut(pkg) {
                    try { act.packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }
                }
                if (ic != null) {
                    ic.setBounds((tx + 20f).toInt(), 576, (tx + 76f).toInt(), 632)
                    ic.draw(c)
                } else txt(c, "+", tx + 48f, 614f, 44f, grey)
            }
        } else {
            txt(c, widgetNames[widget], vw / 2, 200f, 24f, ac, true)
            if (widget == 0) {
                txt(c, hhmm, vw / 2, 400f, 230f, white)
                txt(c, date, vw / 2, 470f, 36f, grey)
            } else {
                txt(c, "In arrivo nella prossima versione", vw / 2, 380f, 44f, white)
            }
        }
        for (k in 0..1) {
            val x = vw / 2 - 19f + (if (k == 0) 0f else 30f)
            box(c, x, 692f, x + (if (k == page) 22f else 8f), 700f, 4f, if (k == page) ac else 0xFF3A4655.toInt())
        }
        c.restore()
        postInvalidateDelayed(50)
    }
}

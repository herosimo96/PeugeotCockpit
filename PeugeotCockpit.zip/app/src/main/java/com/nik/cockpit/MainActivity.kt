package com.nik.cockpit

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NL : NotificationListenerService()

class MainActivity : Activity(), LocationListener {
    private lateinit var cv: CockpitView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cv = CockpitView(this)
        setContentView(cv)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) startGps()
        else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startGps()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK) {
            val u = data?.data
            if (u != null) cv.setBgFromUri(u)
        }
    }

    private fun startGps() {
        try {
            (getSystemService(Context.LOCATION_SERVICE) as LocationManager)
                .requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
        } catch (e: SecurityException) {
        }
    }

    override fun onLocationChanged(location: Location) { cv.onGps(location.speed) }
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    @Deprecated("old api")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onBackPressed() {}
}

class CockpitView(private val act: Activity) : View(act) {
    private class Th(val name: String, val style: Int, val color: Int, val sw: Float)

    private val prefs = act.getSharedPreferences("cp", Context.MODE_PRIVATE)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val themes = arrayOf(
        Th("Cluster verde", 0, 0xFF7DDC6A.toInt(), 8f),
        Th("Classico bianco", 1, 0xFFE8EEF5.toInt(), 4f),
        Th("Sport rosso", 0, 0xFFFF5A5A.toInt(), 18f),
        Th("Neon rosa", 0, 0xFFFF2E93.toInt(), 10f),
        Th("Retro ambra", 1, 0xFFFFB020.toInt(), 4f),
        Th("Neon viola", 2, 0xFFB26BFF.toInt(), 18f),
        Th("Ghiaccio", 0, 0xFF7DF9FF.toInt(), 9f),
        Th("Racing giallo", 2, 0xFFFFD400.toInt(), 22f),
        Th("Matrix", 2, 0xFF39FF14.toInt(), 14f),
        Th("Puro", 0, 0xFFE8EEF5.toInt(), 3f)
    )
    private val wNames = arrayOf("OROLOGIO", "MUSICA", "RADIO", "MAPPA")
    private val bgNames = arrayOf("Tramonto Miami", "Città di notte", "Deserto", "Foto dalla galleria")
    private val white = 0xFFE8EEF5.toInt()
    private val grey = 0xFF9FB0C3.toInt()
    private val red = 0xFFFF6B6B.toInt()
    private val cyan = 0xFF2DE2E6.toInt()
    private val pink = 0xFFFF6FB5.toInt()
    private val ink = 0xFF0A0D12.toInt()
    private var theme = prefs.getInt("theme", 0)
    private var unit = prefs.getInt("unit", 0)
    private var bgPreset = prefs.getInt("bg", 0)
    private var roadOn = prefs.getBoolean("roadOn", true)
    private var roadDir = prefs.getInt("roadDir", 0)
    private var page = 0
    private var odo = prefs.getFloat("odo", 0f)
    private var trip = prefs.getFloat("trip", 0f)
    private var speed = 0f
    private var last = 0L
    private var roadPhase = 0f
    private var sc = 1f
    private var vw = 1280f
    private var doors = 0
    private var hhmm = ""
    private var dateStr = ""
    private var shortDate = ""
    private var ctrl: MediaController? = null
    private var lastPoll = 0L
    private var bgBmp: Bitmap? = null
    private val icons = HashMap<String, Drawable?>()
    private val labels = HashMap<String, String>()
    private val hits = ArrayList<Pair<RectF, Int>>()
    private val bl = arrayOf(
        intArrayOf(70, 26, 120), intArrayOf(92, 34, 160), intArrayOf(124, 22, 100), intArrayOf(144, 30, 140), intArrayOf(176, 26, 90),
        intArrayOf(270, 26, 110), intArrayOf(292, 30, 170), intArrayOf(322, 24, 120), intArrayOf(346, 34, 150), intArrayOf(380, 28, 95)
    )

    init {
        val f = File(act.filesDir, "bg.jpg")
        if (f.exists()) bgBmp = BitmapFactory.decodeFile(f.path)
    }

    fun onGps(ms: Float) {
        val now = System.currentTimeMillis()
        if (last > 0) {
            val km = ms * (now - last) / 1000000f
            odo += km
            trip += km
        }
        last = now
        speed = ms * 3.6f
        prefs.edit().putFloat("odo", odo).putFloat("trip", trip).apply()
    }

    // bit 1 = sportello sinistro, 2 = destro, 4 = baule (per collegare in futuro i dati dell'auto)
    fun setDoors(bits: Int) { doors = bits; postInvalidate() }

    fun setBgFromUri(uri: Uri) {
        try {
            val i1 = act.contentResolver.openInputStream(uri)
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeStream(i1, null, o)
            i1?.close()
            var s = 1
            while (o.outWidth / s > 1600) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val i2 = act.contentResolver.openInputStream(uri)
            val bmp = BitmapFactory.decodeStream(i2, null, o2)
            i2?.close()
            if (bmp != null) {
                FileOutputStream(File(act.filesDir, "bg.jpg")).use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, 90, out) }
                bgBmp = bmp
                bgPreset = 3
                prefs.edit().putInt("bg", 3).apply()
                invalidate()
            }
        } catch (e: Exception) {
            Toast.makeText(act, "Impossibile caricare l'immagine", Toast.LENGTH_LONG).show()
        }
    }

    private fun pickImage() {
        try {
            act.startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 77)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(act, "Nessuna app galleria o file manager trovata", Toast.LENGTH_LONG).show()
        }
    }

    private fun getW(pg: Int): Int =
        if (pg == 0) prefs.getInt("widget", 3) else prefs.getInt("pw$pg", intArrayOf(3, 0, 1, 3)[pg])

    private fun setW(pg: Int, v: Int) {
        prefs.edit().putInt(if (pg == 0) "widget" else "pw$pg", v).apply()
    }

    private val gd = GestureDetector(act, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapUp(e: MotionEvent): Boolean { tap(e.x / sc, e.y / sc, false); return true }
        override fun onLongPress(e: MotionEvent) { tap(e.x / sc, e.y / sc, true) }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 700f) {
                page = if (vx < 0) minOf(page + 1, 3) else maxOf(page - 1, 0)
                invalidate()
                return true
            }
            return false
        }
    })

    override fun onTouchEvent(e: MotionEvent): Boolean = gd.onTouchEvent(e)

    private fun pollMedia() {
        val now = System.currentTimeMillis()
        if (now - lastPoll < 1000) return
        lastPoll = now
        try {
            val msm = act.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val l = msm.getActiveSessions(ComponentName(act, NL::class.java))
            ctrl = l.firstOrNull { s -> s.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
        } catch (e: SecurityException) {
            ctrl = null
        }
    }

    private fun doAction(a: Int) {
        val m = ctrl
        when (a) {
            0 -> m?.transportControls?.skipToPrevious()
            1 -> if (m?.playbackState?.state == PlaybackState.STATE_PLAYING) m?.transportControls?.pause() else m?.transportControls?.play()
            2 -> m?.transportControls?.skipToNext()
            3 -> launchPkg("radioPkg")
            4 -> launchPkg("navPkg")
            else -> {}
        }
    }

    private fun launchPkg(key: String) {
        val pkg = prefs.getString(key, null)
        if (pkg == null) chooseApp(key)
        else act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) }
    }

    private fun tap(x: Float, y: Float, long: Boolean) {
        if (!long && x > vw - 100f && y < 100f) { settings(); return }
        if (!long) {
            for (h in hits) if (h.first.contains(x, y)) { doAction(h.second); invalidate(); return }
        }
        if (page >= 1) {
            if (!long) setW(page, (getW(page) + 1) % 4)
            invalidate()
            return
        }
        for (i in 0..5) {
            val tx = vw / 2 - 270f + i * 92f
            if (x >= tx && x <= tx + 80f && y >= 522f && y <= 602f) {
                val pkg = prefs.getString("t$i", null)
                if (pkg == null || long) chooseApp("t$i")
                else act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) }
                return
            }
        }
        val dx = x - (vw - 220f)
        val dy = y - 300f
        if (dx * dx + dy * dy < 190f * 190f && long) {
            theme = (theme + 1) % themes.size
            prefs.edit().putInt("theme", theme).apply()
        } else if (x < 400f && y > 110f && y < 490f && !long) {
            setW(0, (getW(0) + 1) % 4)
        }
        invalidate()
    }

    private fun chooseApp(key: String) {
        val pm = act.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(q, 0)
            .filter { r -> r.activityInfo.packageName != act.packageName }
            .sortedBy { r -> r.loadLabel(pm).toString().lowercase() }
        val names = list.map { r -> r.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(act).setTitle("Scegli app").setItems(names) { _, w ->
            prefs.edit().putString(key, list[w].activityInfo.packageName).apply()
            icons.clear()
            labels.clear()
            invalidate()
        }.show()
    }

    private fun appLabel(key: String): String {
        val pkg = prefs.getString(key, null) ?: return "nessuna"
        return labelOf(pkg)
    }

    private fun labelOf(pkg: String): String {
        val cached = labels[pkg]
        if (cached != null) return cached
        val l = try {
            val pm = act.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            "app"
        }
        labels[pkg] = l
        return l
    }

    private fun settings() {
        val n = wNames.map { s -> s.lowercase() }
        val items = arrayOf(
            "Tema tachimetro: " + themes[theme].name,
            "Cerchio sinistro: " + n[getW(0)],
            "Pagina 2: " + n[getW(1)],
            "Pagina 3: " + n[getW(2)],
            "Pagina 4: " + n[getW(3)],
            "Sfondo: " + bgNames[bgPreset],
            "Scegli foto dalla galleria",
            "Strada animata: " + (if (roadOn) "sì" else "no"),
            "Direzione strada: " + (if (roadDir == 0) "avanti" else "indietro"),
            "App radio: " + appLabel("radioPkg"),
            "App mappa: " + appLabel("navPkg"),
            "Unità: " + (if (unit == 0) "km/h" else "mph"),
            "Imposta km totali",
            "Azzera trip",
            "Abilita controllo musica",
            "Test sportelli aperti"
        )
        AlertDialog.Builder(act).setTitle("Impostazioni").setItems(items) { _, w ->
            when (w) {
                0 -> pickTheme()
                1 -> pickWidget(0)
                2 -> pickWidget(1)
                3 -> pickWidget(2)
                4 -> pickWidget(3)
                5 -> pickBg()
                6 -> pickImage()
                7 -> { roadOn = !roadOn; prefs.edit().putBoolean("roadOn", roadOn).apply(); invalidate() }
                8 -> { roadDir = 1 - roadDir; prefs.edit().putInt("roadDir", roadDir).apply(); invalidate() }
                9 -> chooseApp("radioPkg")
                10 -> chooseApp("navPkg")
                11 -> { unit = 1 - unit; prefs.edit().putInt("unit", unit).apply(); invalidate() }
                12 -> askOdo()
                13 -> { trip = 0f; prefs.edit().putFloat("trip", 0f).apply(); invalidate() }
                14 -> try {
                    act.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(act, "Vai in Impostazioni Android > Accesso alle notifiche e abilita Peugeot Cockpit", Toast.LENGTH_LONG).show()
                }
                15 -> { doors = (doors + 1) % 5; invalidate() }
                else -> {}
            }
        }.show()
    }

    private fun pickTheme() {
        AlertDialog.Builder(act).setTitle("Tema tachimetro")
            .setItems(themes.map { t -> t.name }.toTypedArray()) { _, w ->
                theme = w
                prefs.edit().putInt("theme", w).apply()
                invalidate()
            }.show()
    }

    private fun pickBg() {
        AlertDialog.Builder(act).setTitle("Sfondo").setItems(bgNames) { _, w ->
            if (w == 3 && bgBmp == null) pickImage()
            else { bgPreset = w; prefs.edit().putInt("bg", w).apply(); invalidate() }
        }.show()
    }

    private fun pickWidget(pg: Int) {
        AlertDialog.Builder(act).setTitle("Widget")
            .setItems(wNames.map { s -> s.lowercase() }.toTypedArray()) { _, w -> setW(pg, w); invalidate() }.show()
    }

    private fun askOdo() {
        val et = EditText(act)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        AlertDialog.Builder(act).setTitle("Km totali dell'auto").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val v = et.text.toString().toFloatOrNull()
                if (v != null) { odo = v; prefs.edit().putFloat("odo", odo).apply(); invalidate() }
            }.setNegativeButton("Annulla", null).show()
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false) {
        p.style = Paint.Style.FILL
        p.color = color
        p.textSize = size
        p.textAlign = Paint.Align.CENTER
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        c.drawText(s, x, y, p)
    }

    private fun box(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        c.drawRoundRect(RectF(l, t, r, b), rad, rad, p)
    }

    private fun outline(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int, w: Float) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = w
        p.color = color
        c.drawRoundRect(RectF(l, t, r, b), rad, rad, p)
    }

    private fun vgrad(c: Canvas, l: Float, t: Float, r: Float, b: Float, colors: IntArray, pos: FloatArray?) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, t, 0f, b, colors, pos, Shader.TileMode.CLAMP)
        c.drawRect(l, t, r, b, p)
        p.shader = null
    }

    // ---------- tachimetro (cerchio destro) ----------
    private fun gauge(c: Canvas, cx: Float, cy: Float, spd: Float) {
        val th = themes[theme]
        val frac = minOf(spd / 200f, 1f)
        p.style = Paint.Style.FILL
        p.color = 0xFF0A0420.toInt()
        c.drawCircle(cx, cy, 178f, p)
        p.color = 0xFF141A38.toInt()
        c.drawCircle(cx, cy, 168f, p)
        val rect = RectF(cx - 158f, cy - 158f, cx + 158f, cy + 158f)
        var numY = cy + 40f
        var numSize = 112f
        var unitY = cy + 78f
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        if (th.style == 1) {
            p.strokeWidth = 3f
            p.color = 0xFF2C3948.toInt()
            c.drawCircle(cx, cy, 168f, p)
            p.strokeWidth = th.sw
            p.color = th.color
            for (i in 0..10) {
                val a = Math.toRadians(135.0 + 27.0 * i)
                val ca = Math.cos(a).toFloat()
                val sa = Math.sin(a).toFloat()
                c.drawLine(cx + 128f * ca, cy + 128f * sa, cx + 150f * ca, cy + 150f * sa, p)
            }
            val na = Math.toRadians(135.0 + 270.0 * frac)
            p.strokeWidth = 6f
            c.drawLine(cx, cy, cx + 112f * Math.cos(na).toFloat(), cy + 112f * Math.sin(na).toFloat(), p)
            p.style = Paint.Style.FILL
            c.drawCircle(cx, cy, 10f, p)
            numY = cy + 92f; numSize = 52f; unitY = cy + 118f
        } else if (th.style == 2) {
            p.strokeWidth = th.sw
            p.strokeCap = Paint.Cap.BUTT
            for (i in 0 until 30) {
                p.color = if (i < frac * 30) th.color else 0xFF1D2733.toInt()
                c.drawArc(rect, 135f + i * 9f, 6.5f, false, p)
            }
        } else {
            p.strokeWidth = 5f
            p.color = white
            c.drawCircle(cx, cy, 170f, p)
            p.strokeWidth = 12f
            p.color = 0xB38FA3C7.toInt()
            p.pathEffect = DashPathEffect(floatArrayOf(2f, 8.8f), 0f)
            c.drawCircle(cx, cy, 138f, p)
            p.pathEffect = null
            p.strokeWidth = th.sw
            p.color = 0xFF1D2733.toInt()
            c.drawArc(rect, 135f, 270f, false, p)
            if (frac > 0.005f) {
                p.color = th.color
                c.drawArc(rect, 135f, 270f * frac, false, p)
            }
            txt(c, "N", cx, cy - 92f, 28f, white, true)
        }
        val shown = if (unit == 1) (spd * 0.621f).toInt() else spd.toInt()
        txt(c, shown.toString(), cx, numY, numSize, white)
        txt(c, if (unit == 1) "MPH" else "KM/H", cx, unitY, 18f, cyan)
    }

    // ---------- widget ----------
    private fun button(c: Canvas, cx: Float, cy: Float, w: Float, h: Float, label: String, action: Int, ac: Int, size: Float) {
        box(c, cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, h / 2, ac)
        txt(c, label, cx, cy + size * 0.35f, size, ink, true)
        hits.add(Pair(RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2), action))
    }

    private fun icon(c: Canvas, kind: Int, x: Float, y: Float, s: Float, playing: Boolean, col: Int) {
        p.style = Paint.Style.FILL
        p.color = col
        val pa = Path()
        if (kind == 0) {
            pa.moveTo(x + s * 0.5f, y - s * 0.5f); pa.lineTo(x - s * 0.4f, y); pa.lineTo(x + s * 0.5f, y + s * 0.5f); pa.close()
            c.drawRect(x - s * 0.7f, y - s * 0.5f, x - s * 0.5f, y + s * 0.5f, p)
        } else if (kind == 2) {
            pa.moveTo(x - s * 0.5f, y - s * 0.5f); pa.lineTo(x + s * 0.4f, y); pa.lineTo(x - s * 0.5f, y + s * 0.5f); pa.close()
            c.drawRect(x + s * 0.5f, y - s * 0.5f, x + s * 0.7f, y + s * 0.5f, p)
        } else if (playing) {
            c.drawRect(x - s * 0.45f, y - s * 0.5f, x - s * 0.12f, y + s * 0.5f, p)
            c.drawRect(x + s * 0.12f, y - s * 0.5f, x + s * 0.45f, y + s * 0.5f, p)
        } else {
            pa.moveTo(x - s * 0.35f, y - s * 0.55f); pa.lineTo(x - s * 0.35f, y + s * 0.55f); pa.lineTo(x + s * 0.55f, y); pa.close()
        }
        c.drawPath(pa, p)
    }

    private fun cut(s: String): String = if (s.length > 16) s.take(15) + "…" else s

    private fun media(c: Canvas, cx: Float, cy: Float, k: Float, ac: Int) {
        pollMedia()
        val m = ctrl
        val title = m?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Nessun brano"
        val artist = m?.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Abilita il controllo musica"
        txt(c, cut(title), cx, cy - 14f * k, 26f * k, white)
        txt(c, cut(artist), cx, cy + 18f * k, 18f * k, grey)
        val playing = m?.playbackState?.state == PlaybackState.STATE_PLAYING
        val by = cy + 80f * k
        val g = 76f * k
        val r = 26f * k
        for (j in 0..2) {
            val bx = cx + (j - 1) * g
            p.style = Paint.Style.FILL
            p.color = if (j == 1) ac else 0xFF1D2733.toInt()
            c.drawCircle(bx, by, r, p)
            icon(c, j, bx, by, 12f * k, playing, if (j == 1) ink else white)
            hits.add(Pair(RectF(bx - r, by - r, bx + r, by + r), j))
        }
    }

    private fun minimap(c: Canvas, cx: Float, cy: Float) {
        c.save()
        val cp = Path()
        cp.addCircle(cx, cy, 168f, Path.Direction.CW)
        c.clipPath(cp)
        p.style = Paint.Style.FILL
        p.color = 0xFF1B2542.toInt()
        c.drawRect(cx - 170f, cy - 170f, cx + 170f, cy + 170f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = 0x8C7F93BD.toInt()
        var g = -168f
        while (g <= 168f) {
            c.drawLine(cx + g, cy - 170f, cx + g, cy + 170f, p)
            c.drawLine(cx - 170f, cy + g, cx + 170f, cy + g, p)
            g += 56f
        }
        p.style = Paint.Style.FILL
        p.color = 0xFF26335A.toInt()
        c.drawRect(cx - 130f, cy + 40f, cx - 60f, cy + 100f, p)
        c.drawRect(cx + 60f, cy - 110f, cx + 124f, cy - 40f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 8f
        p.color = 0xB39FB0D8.toInt()
        c.drawLine(cx - 150f, cy + 170f, cx + 170f, cy - 150f, p)
        val route = Path()
        route.moveTo(cx - 15f, cy + 170f); route.lineTo(cx - 15f, cy + 40f); route.lineTo(cx + 10f, cy); route.lineTo(cx + 25f, cy - 170f)
        p.strokeWidth = 9f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = 0xFFB48CFF.toInt()
        c.drawPath(route, p)
        val ar = Path()
        ar.moveTo(cx, cy - 14f); ar.lineTo(cx - 14f, cy + 22f); ar.lineTo(cx, cy + 14f); ar.lineTo(cx + 14f, cy + 22f); ar.close()
        p.style = Paint.Style.FILL
        p.color = 0xFFFFFFFF.toInt()
        c.drawPath(ar, p)
        c.restore()
        button(c, cx, cy + 110f, 150f, 40f, "Apri mappa", 4, cyan, 16f)
    }

    private fun widgetBody(c: Canvas, type: Int, cx: Float, cy: Float, k: Float, ac: Int) {
        if (!(type == 3 && k <= 1.1f)) txt(c, wNames[type], cx, cy - 78f * k, 18f * k, ac, true)
        when (type) {
            0 -> {
                txt(c, hhmm, cx, cy + 20f * k, 70f * k, white)
                txt(c, dateStr, cx, cy + 62f * k, 20f * k, grey)
            }
            1 -> media(c, cx, cy, k, ac)
            2 -> {
                txt(c, appLabel("radioPkg"), cx, cy - 6f * k, 26f * k, white)
                button(c, cx, cy + 60f * k, 210f * k, 56f * k, "Apri radio", 3, ac, 22f * k)
            }
            else -> {
                if (k <= 1.1f) minimap(c, cx, cy - 10f)
                else {
                    txt(c, appLabel("navPkg"), cx, cy - 6f * k, 26f * k, white)
                    button(c, cx, cy + 60f * k, 210f * k, 56f * k, "Apri mappa", 4, ac, 22f * k)
                }
            }
        }
    }

    // ---------- scena centrale ----------
    private fun palmTree(c: Canvas, x: Float, y: Float, h: Float) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0xFF12062E.toInt()
        p.strokeWidth = 8f
        val tr = Path()
        tr.moveTo(x, y); tr.quadTo(x + 10f, y - h / 2, x - 6f, y - h)
        c.drawPath(tr, p)
        val tx = x - 6f
        val ty = y - h
        p.strokeWidth = 6f
        val fr = Path()
        fr.moveTo(tx, ty); fr.rQuadTo(-46f, -12f, -80f, 28f)
        fr.moveTo(tx, ty); fr.rQuadTo(-30f, -40f, -70f, -22f)
        fr.moveTo(tx, ty); fr.rQuadTo(46f, -12f, 80f, 28f)
        fr.moveTo(tx, ty); fr.rQuadTo(30f, -40f, 70f, -22f)
        fr.moveTo(tx, ty); fr.rQuadTo(-6f, -46f, 6f, -52f)
        c.drawPath(fr, p)
    }

    private fun buildings(c: Canvas, c1: Int, c2: Int, win: Int) {
        p.style = Paint.Style.FILL
        for (i in bl.indices) {
            val x = bl[i][0].toFloat()
            val w = bl[i][1].toFloat()
            val h = bl[i][2].toFloat()
            p.color = if (i % 2 == 0) c1 else c2
            c.drawRect(x, 250f - h, x + w, 250f, p)
            p.color = win
            var y = 250f - h + 14f
            while (y < 238f) {
                var xx = x + 5f
                while (xx < x + w - 6f) {
                    c.drawRect(xx, y, xx + 3f, y + 4f, p)
                    xx += 8f
                }
                y += 16f
            }
        }
    }

    private fun sunBars(c: Canvas, x: Float, col: Int) {
        p.style = Paint.Style.FILL
        p.color = col
        val ys = floatArrayOf(258f, 270f, 284f, 300f, 318f)
        val ws = floatArrayOf(110f, 86f, 64f, 44f, 26f)
        for (i in 0..4) c.drawRoundRect(RectF(x - ws[i] / 2, ys[i], x + ws[i] / 2, ys[i] + 5f), 2f, 2f, p)
    }

    private fun sceneMiami(c: Canvas) {
        vgrad(c, 0f, 0f, 480f, 250f, intArrayOf(0xFF1A0A4A.toInt(), 0xFF5A1A9A.toInt(), 0xFFD92F94.toInt(), 0xFFFF8A3C.toInt()), floatArrayOf(0f, 0.35f, 0.7f, 1f))
        c.save()
        c.clipRect(0f, 0f, 480f, 250f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 172f, 0f, 328f, 0xFFFFE25C.toInt(), 0xFFFF4FA0.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(240f, 250f, 78f, p)
        p.shader = null
        c.restore()
        buildings(c, 0xFF3A1480.toInt(), 0xFF4A1C9A.toInt(), 0xA6B9A8FF.toInt())
        palmTree(c, 34f, 262f, 215f)
        palmTree(c, 450f, 262f, 200f)
        vgrad(c, 0f, 250f, 480f, 370f, intArrayOf(0xFF4A1580.toInt(), 0xFF12062E.toInt()), null)
        sunBars(c, 240f, 0xB3FFCF6A.toInt())
    }

    private fun sceneNight(c: Canvas) {
        vgrad(c, 0f, 0f, 480f, 250f, intArrayOf(0xFF050816.toInt(), 0xFF0B1F4A.toInt(), 0xFF1B3A7A.toInt()), null)
        p.style = Paint.Style.FILL
        p.color = 0xFFEAF2FF.toInt()
        c.drawCircle(380f, 70f, 26f, p)
        p.color = 0xCCFFFFFF.toInt()
        val sx = intArrayOf(40, 110, 180, 250, 320, 440, 70, 210, 290, 420)
        val sy = intArrayOf(30, 80, 40, 100, 50, 120, 140, 20, 150, 160)
        for (i in sx.indices) c.drawCircle(sx[i].toFloat(), sy[i].toFloat(), 2f, p)
        buildings(c, 0xFF0D1B3A.toInt(), 0xFF13264F.toInt(), 0xB0FFE08A.toInt())
        vgrad(c, 0f, 250f, 480f, 370f, intArrayOf(0xFF0B1F4A.toInt(), 0xFF050816.toInt()), null)
        sunBars(c, 380f, 0x80EAF2FF.toInt())
    }

    private fun sceneDesert(c: Canvas) {
        vgrad(c, 0f, 0f, 480f, 250f, intArrayOf(0xFF3A1A0A.toInt(), 0xFFB8501C.toInt(), 0xFFFFB060.toInt()), null)
        c.save()
        c.clipRect(0f, 0f, 480f, 250f)
        p.style = Paint.Style.FILL
        p.color = 0xFFFFE08A.toInt()
        c.drawCircle(240f, 250f, 90f, p)
        c.restore()
        p.color = 0xFF8A3A14.toInt()
        c.drawOval(RectF(-80f, 200f, 200f, 300f), p)
        c.drawOval(RectF(150f, 215f, 430f, 320f), p)
        c.drawOval(RectF(320f, 190f, 620f, 300f), p)
        vgrad(c, 0f, 250f, 480f, 370f, intArrayOf(0xFF7A3512.toInt(), 0xFF3A1A0A.toInt()), null)
    }

    private fun sceneImage(c: Canvas) {
        val b = bgBmp
        if (b == null) { sceneMiami(c); return }
        val sw = b.width.toFloat()
        val sh = b.height.toFloat()
        val tr = 480f / 370f
        val src = if (sw / sh > tr) {
            val w2 = sh * tr
            Rect(((sw - w2) / 2).toInt(), 0, ((sw + w2) / 2).toInt(), b.height)
        } else {
            val h2 = sw / tr
            Rect(0, ((sh - h2) / 2).toInt(), b.width, ((sh + h2) / 2).toInt())
        }
        c.drawBitmap(b, src, RectF(0f, 0f, 480f, 370f), null)
    }

    private fun road(c: Canvas, spd: Float) {
        val rd = Path()
        rd.moveTo(226f, 250f); rd.lineTo(254f, 250f); rd.lineTo(470f, 370f); rd.lineTo(10f, 370f); rd.close()
        p.style = Paint.Style.FILL
        p.color = 0xFF0D0420.toInt()
        c.drawPath(rd, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = 0xFFFF2E93.toInt()
        c.drawLine(226f, 250f, 10f, 370f, p)
        c.drawLine(254f, 250f, 470f, 370f, p)
        if (roadOn && spd > 3f) {
            val dir = if (roadDir == 0) 1f else -1f
            roadPhase = ((roadPhase + dir * spd * 0.0004f) % 1f + 1f) % 1f
        }
        p.style = Paint.Style.FILL
        p.color = 0xFFFFB3D9.toInt()
        for (i in 0 until 5) {
            val d1 = (i / 5f + roadPhase) % 1f
            val d2 = minOf(d1 + 0.1f, 1f)
            val y1 = 250f + 120f * d1 * d1
            val y2 = 250f + 120f * d2 * d2
            val w1 = 1.5f + (y1 - 250f) * 0.06f
            val w2 = 1.5f + (y2 - 250f) * 0.06f
            val dp = Path()
            dp.moveTo(240f - w1, y1); dp.lineTo(240f + w1, y1); dp.lineTo(240f + w2, y2); dp.lineTo(240f - w2, y2); dp.close()
            c.drawPath(dp, p)
        }
    }

    private fun scene(c: Canvas, cx: Float, spd: Float) {
        c.save()
        c.translate(cx - 240f, 110f)
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, 480f, 370f), 22f, 22f, Path.Direction.CW)
        c.clipPath(clip)
        when (bgPreset) {
            1 -> sceneNight(c)
            2 -> sceneDesert(c)
            3 -> sceneImage(c)
            else -> sceneMiami(c)
        }
        road(c, spd)
        c.restore()
        outline(c, cx - 239f, 111f, cx + 239f, 479f, 22f, 0xFF7A4AA8.toInt(), 2f)
    }

    private fun car(c: Canvas, cx: Float, spd: Float) {
        c.save()
        c.translate(cx - 130f, 263f)
        c.scale(0.65f, 0.65f)
        p.style = Paint.Style.FILL
        p.color = 0x59FF2E93
        c.drawOval(RectF(10f, 302f, 390f, 342f), p)
        p.color = 0xFF05010F.toInt()
        c.drawOval(RectF(35f, 304f, 365f, 332f), p)
        val cab = Path()
        cab.moveTo(82f, 150f); cab.lineTo(108f, 62f); cab.quadTo(112f, 48f, 130f, 48f)
        cab.lineTo(270f, 48f); cab.quadTo(288f, 48f, 292f, 62f); cab.lineTo(318f, 150f); cab.close()
        p.color = 0xFF6D6A86.toInt()
        c.drawPath(cab, p)
        val win = Path()
        win.moveTo(106f, 142f); win.lineTo(126f, 70f); win.lineTo(274f, 70f); win.lineTo(294f, 142f); win.close()
        p.color = 0xFF150A2E.toInt()
        c.drawPath(win, p)
        val door = Path()
        if ((doors and 1) != 0) { door.moveTo(40f, 160f); door.lineTo(4f, 178f); door.lineTo(4f, 276f); door.lineTo(40f, 268f); door.close() }
        if ((doors and 2) != 0) { door.moveTo(360f, 160f); door.lineTo(396f, 178f); door.lineTo(396f, 276f); door.lineTo(360f, 268f); door.close() }
        p.color = 0xFFB4B2C8.toInt()
        c.drawPath(door, p)
        box(c, 40f, 148f, 360f, 278f, 30f, 0xFF9A98B0.toInt())
        box(c, 46f, 162f, 110f, 202f, 8f, 0xFFFF2E5B.toInt())
        box(c, 290f, 162f, 354f, 202f, 8f, 0xFFFF2E5B.toInt())
        box(c, 162f, 214f, 238f, 240f, 4f, 0xFFF2EAFF.toInt())
        box(c, 56f, 250f, 344f, 290f, 14f, 0xFF3A3550.toInt())
        box(c, 62f, 288f, 114f, 318f, 6f, 0xFF0B0618.toInt())
        box(c, 286f, 288f, 338f, 318f, 6f, 0xFF0B0618.toInt())
        if ((doors and 4) != 0) box(c, 100f, 34f, 300f, 46f, 6f, red)
        c.restore()
        if (doors == 0) {
            txt(c, if (spd > 3f) "IN MOVIMENTO" else "FERMA", cx, 506f, 14f, grey)
        } else {
            val parts = ArrayList<String>()
            if ((doors and 1) != 0) parts.add("SPORTELLO SX")
            if ((doors and 2) != 0) parts.add("SPORTELLO DX")
            if ((doors and 4) != 0) parts.add("BAULE")
            txt(c, parts.joinToString(" + ") + " APERTO", cx, 506f, 14f, red, true)
        }
    }

    // ---------- disegno ----------
    override fun onDraw(c: Canvas) {
        sc = height / 720f
        vw = width / sc
        hits.clear()
        c.drawColor(0xFF0A0420.toInt())
        c.save()
        c.scale(sc, sc)
        val now = Date()
        hhmm = SimpleDateFormat("HH:mm", Locale.ITALY).format(now)
        dateStr = SimpleDateFormat("EEEE d MMMM", Locale.ITALY).format(now)
        shortDate = SimpleDateFormat("EEE d MMM", Locale.ITALY).format(now)
        val spd = if (System.currentTimeMillis() - last > 3000) 0f else speed
        val cx = vw / 2
        txt(c, hhmm, 90f, 56f, 32f, white, true)
        val lamps = intArrayOf(0xFF52E07A.toInt(), 0xFFFFB020.toInt(), 0xFFFF6FB5.toInt(), 0xFF2DE2E6.toInt(), 0xFF52E07A.toInt())
        for (i in 0..4) {
            val lx = cx - 56f + i * 28f
            p.style = Paint.Style.FILL
            p.color = (lamps[i] and 0x00FFFFFF) or 0x55000000
            c.drawCircle(lx, 40f, 11f, p)
            p.color = lamps[i]
            c.drawCircle(lx, 40f, 6f, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = grey
        c.drawCircle(vw - 50f, 44f, 6f, p)
        p.pathEffect = DashPathEffect(floatArrayOf(5f, 5f), 0f)
        c.drawCircle(vw - 50f, 44f, 15f, p)
        p.pathEffect = null
        if (page == 0) {
            val lx = 220f
            p.style = Paint.Style.FILL
            p.color = 0xFF0A0420.toInt()
            c.drawCircle(lx, 300f, 178f, p)
            p.color = 0xFF141A38.toInt()
            c.drawCircle(lx, 300f, 168f, p)
            widgetBody(c, getW(0), lx, 310f, 1f, cyan)
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 5f
            p.color = white
            c.drawCircle(lx, 300f, 172f, p)
            p.strokeWidth = 8f
            p.color = 0xFF7DDC6A.toInt()
            c.drawArc(RectF(lx - 172f, 128f, lx + 172f, 472f), 180f, 80f, false, p)
            for (k in 0..3) txt(c, wNames[k].lowercase(), lx - 135f + k * 90f, 500f, 14f, if (k == getW(0)) cyan else grey)
            gauge(c, vw - 220f, 300f, spd)
            scene(c, cx, spd)
            car(c, cx, spd)
            for (i in 0..5) {
                val tx = cx - 270f + i * 92f
                val col = if (i % 2 == 0) pink else cyan
                box(c, tx, 522f, tx + 80f, 602f, 20f, 0xD914052B.toInt())
                outline(c, tx, 522f, tx + 80f, 602f, 20f, col, 2f)
                val pkg = prefs.getString("t$i", null)
                val ic = if (pkg == null) null else icons.getOrPut(pkg) {
                    try { act.packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }
                }
                if (ic != null && pkg != null) {
                    ic.setBounds((tx + 20f).toInt(), 530, (tx + 60f).toInt(), 570)
                    ic.draw(c)
                    txt(c, labelOf(pkg).take(10), tx + 40f, 592f, 11f, white)
                } else txt(c, "+", tx + 40f, 574f, 40f, col)
            }
            box(c, cx - 340f, 624f, cx + 340f, 670f, 23f, 0xD914052B.toInt())
            outline(c, cx - 340f, 624f, cx + 340f, 670f, 23f, 0xFF7A4AA8.toInt(), 2f)
            txt(c, "TRIP " + String.format(Locale.ITALY, "%.1f", trip) + " KM", cx - 230f, 654f, 17f, white, true)
            txt(c, shortDate.uppercase(), cx, 654f, 17f, grey)
            txt(c, odo.toInt().toString() + " KM", cx + 230f, 654f, 17f, white, true)
        } else {
            widgetBody(c, getW(page), cx, 330f, 2.2f, cyan)
        }
        var x = cx - 35f
        for (k in 0..3) {
            val w = if (k == page) 22f else 8f
            box(c, x, 700f, x + w, 708f, 4f, if (k == page) cyan else 0xFF3A4655.toInt())
            x += w + 8f
        }
        c.restore()
        postInvalidateDelayed(50)
    }
}
